rm allreport.txt
cd simple_chat_ai
rm cve_numbers.txt
rm cve_numbers1.txt
